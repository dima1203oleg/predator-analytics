"""VPC - Verifiable Physical Consequences"""
