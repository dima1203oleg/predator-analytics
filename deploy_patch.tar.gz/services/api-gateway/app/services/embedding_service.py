import logging
import os
from typing import List
import numpy as np

logger = logging.getLogger("service.embedding")

class EmbeddingService:
    """
    Service for generating text embeddings for semantic search.
    Uses sentence-transformers for vector generation.
    **CONSTITUTIONAL COMPLIANCE**:
    - Respects Axiom 1 (Compute Distribution).
    - Uses Mock/Dummy implementation on non-GPU tiers.
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Initialize embedding service.

        Args:
            model_name: HuggingFace model name (default: all-MiniLM-L6-v2, 384 dimensions)
        """
        self.model_name = model_name
        self.vector_size = 384  # for all-MiniLM-L6-v2
        self.model = None
        self.reranker = None
        self.reranker_model_name = "cross-encoder/ms-marco-MiniLM-L-6-v2"

        # Constitutional Check
        self.compute_tier = os.environ.get("COMPUTE_TIER", "basic").lower()
        self.is_gpu_tier = self.compute_tier in ["gpu", "heavy", "ml"]

        # Lazy loading - only load when first needed
        logger.info(f"Embedding service initialized with model: {model_name} (Tier: {self.compute_tier})")

        # Batching service
        self._batch_service = None

    def _load_model(self):
        """Lazy load the model. Enforces Axiom 1: No Heavy Compute on Basic Tier."""
        if self.model is None:
            # 1. Check Constitution
            if not self.is_gpu_tier:
                logger.warning(
                    f"⚠️  [CONSTITUTION AXIOM 1] Heavy Compute requested on '{self.compute_tier}' tier."
                    " Offloading to Dummy Model. Real processing requires REMOTE_GPU_SERVER."
                )
                self._load_dummy_model()
                return

            # 2. Load Real Model (Only on GPU Tier)
            try:
                from sentence_transformers import SentenceTransformer
                from sentence_transformers import CrossEncoder
                self.model = SentenceTransformer(self.model_name)
                logger.info(f"Loaded embedding model: {self.model_name}")

                # Load reranker
                self.reranker = CrossEncoder(self.reranker_model_name)
                logger.info(f"Loaded reranker model: {self.reranker_model_name}")
            except ImportError:
                logger.warning("sentence-transformers not installed. Using fallback DummyModel.")
                self._load_dummy_model()
            except Exception as e:
                logger.error(f"Failed to load model: {e}")
                raise

    def _load_dummy_model(self):
        """Load compliant dummy model for local/basic tiers."""
        class DummyModel:
            def encode(self, text, convert_to_numpy=True, show_progress_bar=False):
                # Return 384-dim vector with small noise (matches all-MiniLM-L6-v2)
                # Prevents Divide-by-Zero in cosine similarity (Axiom 16 Resilience)
                if isinstance(text, list):
                    return np.random.rand(len(text), 384) * 0.01
                return np.random.rand(384) * 0.01

        self.model = DummyModel()
        self.reranker = None  # No reranking locally

    async def generate_embedding_async(self, text: str) -> List[float]:
        """
        Generate embedding vector asynchronously with dynamic batching.
        """
        if self._batch_service is None:
            from app.services.batch_embedder import BatchEmbeddingService
            self._batch_service = BatchEmbeddingService(self)
            self._batch_service.start()

        return await self._batch_service.embed_async(text)

    def generate_embedding(self, text: str) -> List[float]:
        """
        Generate embedding vector for text.
        Blocking call - verify safe usage or use generate_embedding_async.

        Args:
            text: Input text

        Returns:
            List of floats (vector representation)
        """
        self._load_model()

        try:
            embedding = self.model.encode(text, convert_to_numpy=True)
            return embedding.tolist()
        except Exception as e:
            logger.error(f"Embedding generation failed: {e}")
            # Return zero vector as fallback
            return [0.0] * self.vector_size

    def generate_batch_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts (batch processing).

        Args:
            texts: List of input texts

        Returns:
            List of embedding vectors
        """
        self._load_model()

        try:
            embeddings = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=True)
            return embeddings.tolist()
        except Exception as e:
            logger.error(f"Batch embedding generation failed: {e}")
            return [[0.0] * self.vector_size] * len(texts)

    def cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """
        Calculate cosine similarity between two vectors.

        Args:
            vec1: First vector
            vec2: Second vector

        Returns:
            Similarity score (0-1)
        """
        v1 = np.array(vec1)
        v2 = np.array(vec2)

        dot_product = np.dot(v1, v2)
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)

        if norm_v1 == 0 or norm_v2 == 0:
            return 0.0

        return float(dot_product / (norm_v1 * norm_v2))

    def rerank(self, query: str, documents: List[str]) -> List[float]:
        """
        Rerank a list of documents based on relevance to the query using a Cross-Encoder.

        Args:
            query: The search query
            documents: List of document texts to score

        Returns:
            List of scores (higher is better)
        """
        self._load_model()

        if not documents:
            return []

        try:
            # Prepare pairs for cross-encoder
            pairs = [[query, doc] for doc in documents]

            # Predict scores
            scores = self.reranker.predict(pairs)
            return scores.tolist()
        except Exception as e:
            logger.error(f"Reranking failed: {e}")
            # Fallback: return 0.0 scores
            return [0.0] * len(documents)

    # =====================
    # MULTIMODAL (CLIP)
    # =====================

    def _load_clip_model(self):
        """Lazy load CLIP model."""
        if not hasattr(self, 'clip_model') or self.clip_model is None:
            try:
                from sentence_transformers import SentenceTransformer
                self.clip_model = SentenceTransformer('clip-ViT-B-32')
                logger.info("Loaded CLIP model: clip-ViT-B-32")
            except Exception as e:
                logger.error(f"Failed to load CLIP model: {e}")
                raise

    def generate_clip_embedding(self, text: str = None, image_path: str = None) -> List[float]:
        """
        Generate multimodal embedding using CLIP.
        Supports text OR image input.
        """
        self._load_clip_model()

        try:
            if text:
                return self.clip_model.encode(text).tolist()

            if image_path:
                from PIL import Image
                image = Image.open(image_path)
                return self.clip_model.encode(image).tolist()

            return [0.0] * 512

        except Exception as e:
            logger.error(f"CLIP embedding failed: {e}")
            return [0.0] * 512


# Singleton
_embedding_service = EmbeddingService()

def get_embedding_service() -> EmbeddingService:
    return _embedding_service
