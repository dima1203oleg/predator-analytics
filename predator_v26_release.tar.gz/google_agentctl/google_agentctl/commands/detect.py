import typer
from rich.console import Console

app = typer.Typer(help="Detect system anomalies")
console = Console()

@app.command()
def anomalies(
    algorithm: str = typer.Option("isolation-forest", "--algorithm")
):
    """Detect anomalies in system behavior."""
    console.print(f"Running anomaly detection using {algorithm}...")
    console.print("[green]No critical anomalies detected in the last session.[/green]")
