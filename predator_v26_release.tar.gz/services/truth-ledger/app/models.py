from sqlalchemy import Column, Integer, String, JSON, DateTime, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
import hashlib
import json

Base = declarative_base()

class LedgerEntry(Base):
    __tablename__ = 'truth_ledger'

    id = Column(Integer, primary_key=True, index=True)
    previous_hash = Column(String, nullable=False, index=True)
    data_hash = Column(String, nullable=False)

    # Metadata
    entity_type = Column(String, nullable=False) # e.g., 'etl_job', 'model_update'
    entity_id = Column(String, nullable=False)
    action = Column(String, nullable=False) # e.g., 'approve', 'deny'

    # The actual payload (state change)
    payload = Column(JSON, nullable=False)

    # Constitutional Context
    constitution_version = Column(String, nullable=False, default='v26')
    arbiter_signature = Column(String, nullable=True) # Ed25519 signature

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def calculate_hash(self):
        """Calculates the hash of the entry including previous hash to form the chain."""
        content = {
            "previous_hash": self.previous_hash,
            "entity_type": self.entity_type,
            "entity_id": self.entity_id,
            "action": self.action,
            "payload": self.payload,
            "created_at": str(self.created_at)
        }
        return hashlib.sha256(json.dumps(content, sort_keys=True).encode()).hexdigest()

class AuditLog(Base):
    __tablename__ = 'audit_chain'

    id = Column(Integer, primary_key=True)
    ledger_entry_id = Column(Integer, ForeignKey('truth_ledger.id'))
    auditor_id = Column(String, nullable=False)
    verification_status = Column(Boolean, default=False)
    verified_at = Column(DateTime(timezone=True), server_default=func.now())
