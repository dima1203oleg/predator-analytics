import os
import sys
import time
from app.services.voice_service import VoiceService

# Просте перехоплення gettext для main файлу, якщо потрібно,
# або покладаємось на те, що VoiceService вже налаштував середовище,
# але краще явно імпортувати _
import gettext
locale_path = os.path.join(os.path.dirname(__file__), 'locales')
try:
    uk_trans = gettext.translation('messages', localedir=locale_path, languages=['uk'])
    uk_trans.install()
    _ = uk_trans.gettext
except Exception:
    _ = lambda s: s

def main():
    """
    Головна функція запуску сервера та демонстрації можливостей.
    """
    print("════════════════════════════════════════════════════")
    print(_("Starting Predator Voice Server..."))
    print("════════════════════════════════════════════════════")

    # Перевірка наявності ключів
    creds = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
    if not creds:
        print("❌ УВАГА: Змінна 'GOOGLE_APPLICATION_CREDENTIALS' не встановлена.")
        print("   Переконайтеся, що файл ключів доступний для Docker контейнера або локального запуску.")
    else:
        print(f"✅ Ключі знайдено: {creds}")

    # Ініціалізація сервісу
    try:
        service = VoiceService()

        # Демонстрація TTS
        test_text = "Ласкаво просимо до системи Predator. Всі системи працюють у штатному режимі."
        output_file = "startup_check.mp3"
        print(f"\n📢 Тестування синтезу мовлення: '{test_text}'")

        try:
            service.text_to_speech(test_text, output_file)
            print(f"✅ Файл створено: {output_file}")
        except Exception as e:
             print(f"⚠️ Помилка TTS (це нормально, якщо ключі недійсні): {e}")

        # Імітація запуску сервера (Long-running process)
        print("\n" + _("Server is running on port 8080."))
        print("(Натисніть Ctrl+C для зупинки)")

        # У реальному застосунку тут був би запуск веб-сервера (FastAPI/Flask)
        # Для демо ми просто тримаємо процес активним
        while True:
            time.sleep(60)

    except Exception as e:
        print(f"❌ Критична помилка: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
