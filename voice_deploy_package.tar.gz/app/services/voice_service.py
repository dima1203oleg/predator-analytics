import os
import gettext
import logging
from google.cloud import texttospeech
from google.cloud import speech

# Налаштування логування
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Налаштування локалізації (i18n)
# Ми очікуємо структуру каталогів: locales/uk/LC_MESSAGES/messages.mo
locale_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'locales')
try:
    uk_trans = gettext.translation('messages', localedir=locale_path, languages=['uk'])
    uk_trans.install()
    _ = uk_trans.gettext
except FileNotFoundError:
    # Fallback, якщо скомпільований .mo файл відсутній
    logging.warning("Файл перекладу .mo не знайдено. Використовується режим за замовчуванням.")
    _ = lambda s: s

class VoiceService:
    """
    Сервіс для обробки голосу, що використовує Google Cloud API.
    Всі операції суворо налаштовані на українську мову (uk-UA).
    """

    def __init__(self):
        """
        Ініціалізує клієнти Google Cloud Speech та Text-to-Speech.
        Перевіряє наявність змінних середовища для аутентифікації.
        """
        if not os.environ.get('GOOGLE_APPLICATION_CREDENTIALS'):
            logger.error(_("Google Cloud credentials not found."))
            print(_("Google Cloud credentials not found."))
        else:
            logger.info(_("Voice service initialized successfully."))

        # Ініціалізація клієнтів
        self.tts_client = texttospeech.TextToSpeechClient()
        self.stt_client = speech.SpeechClient()

        # Сувора конфігурація мови
        self.language_code = "uk-UA"
        self.voice_name = "uk-UA-Wavenet-A" # Жіночий преміум голос

    def text_to_speech(self, text: str, output_filename: str) -> str:
        """
        Перетворює текст у мовлення (MP3).

        :param text: Текст українською мовою.
        :param output_filename: Шлях до вихідного файлу.
        :return: Шлях до створеного файлу.
        """
        logger.info(_("Synthesizing text to speech..."))

        input_text = texttospeech.SynthesisInput(text=text)

        voice = texttospeech.VoiceSelectionParams(
            language_code=self.language_code,
            name=self.voice_name,
            ssml_gender=texttospeech.SsmlVoiceGender.FEMALE
        )

        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3
        )

        response = self.tts_client.synthesize_speech(
            input=input_text, voice=voice, audio_config=audio_config
        )

        # Запис бінарного контенту у файл
        with open(output_filename, "wb") as out:
            out.write(response.audio_content)
            logger.info(_("Text synthesized and saved to file.") + f" [{output_filename}]")

        return output_filename

    def speech_to_text(self, audio_filename: str) -> str:
        """
        Розпізнає мовлення з аудіофайлу.

        :param audio_filename: Шлях до вхідного аудіофайлу.
        :return: Розпізнаний текст.
        """
        logger.info(_("Recognizing speech from audio file..."))

        try:
            with open(audio_filename, "rb") as audio_file:
                content = audio_file.read()
        except FileNotFoundError:
            logger.error(f"Файл {audio_filename} не знайдено.")
            return ""

        audio = speech.RecognitionAudio(content=content)

        # Автоматичне визначення параметрів або налаштування за замовчуванням
        # Для кращої сумісності бажано передавати WAV/FLAC, але спробуємо ідентифікувати
        config = speech.RecognitionConfig(
            language_code=self.language_code,
            enable_automatic_punctuation=True,
        )

        response = self.stt_client.recognize(config=config, audio=audio)

        transcript_list = []
        for result in response.results:
            transcript_list.append(result.alternatives[0].transcript)

        full_text = " ".join(transcript_list)
        logger.info(_("Speech recognition completed."))
        return full_text
